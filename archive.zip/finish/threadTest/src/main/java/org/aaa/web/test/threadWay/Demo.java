package org.aaa.web.test.threadWay;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Demo {
	
	

	public static void main(String[] args) {
		  long time1 = System.currentTimeMillis();
		  Integer ThreadCount=0;
		 
		  /*ThreadTest1 R1 = new ThreadTest1( "Thread-1");
	      ThreadTest1 R2 = new ThreadTest1( "Thread-2");
	      R1.start();
	      R2.start();*/
	      
	      ThreadTest1 R = new ThreadTest1();
	      Thread t1 = new Thread(R,"Thread-1");
	      Thread t2 = new Thread(R,"Thread-2");
	      Thread t3 = new Thread(R,"Thread-3");
	      /*Thread t1=new Thread(R, "t1");
	      Thread t2=new Thread(R, "t2");*/
	      t1.start();
	      t2.start();
	      t3.start();
	     
	      
	      
	      List<Thread> list=new ArrayList<Thread>();
	      list.add(t1);
	      list.add(t2);
	      list.add(t3);
	      /*ThreadTest1 R3 = new ThreadTest1( "Thread-3", num);
	      R3.start();
	     
	      ThreadTest1 R4 = new ThreadTest1( "Thread-4");
	      R4.start(); 
	      
	      ThreadTest1 R5 = new ThreadTest1( "Thread-5");
	      R5.start();
	      
	      ThreadTest1 R6 = new ThreadTest1( "Thread-6");
	      R6.start();*/ 
	      
			try {
				 for (Thread item : list) {
				   item.join();
				 }
				 long time2 = System.currentTimeMillis();
			     System.out.println("num:"+R.getNum()+"--耗时："+(time2-time1));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     
	      
	}
	
	
	

}



 
