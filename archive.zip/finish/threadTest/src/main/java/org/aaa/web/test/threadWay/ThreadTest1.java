package org.aaa.web.test.threadWay;

import java.util.Date;

/**
 * @author shadow
 * 继承Thread类创建线程测试。
 *
 */
public class ThreadTest1 extends Thread{

	private Thread t;
	private String threadName;
	private int num=0;
	private long time1;
	private long time2;
	
	
	public ThreadTest1() {
		
	}
	
	ThreadTest1 (String name ,Thread myT){
		this.t=myT;
		this.threadName=name;
		System.out.println("create:"+name );
	}
	public  int getNum() {
        return this.num;
    }
	
	
	public void start () {
		if (t==null) {
		   t = new Thread (this, threadName);
		   t.start ();
		}
		  
	      System.out.println("Starting " +  threadName );
	   }

	@Override
	public void run() {
		//super.run();
		this.time1 = System.currentTimeMillis();
		for (int i = 0; i < 1000; i++) {
			this.num=this.num+1;
			//System.out.println("runing:"+this.getName()+"--num:"+this.num );
		}
		
		/*while(this.num<1000) {
			this.num=this.num+1;
			//System.out.println("runing:"+threadName+"--num:"+this.num );
		}*/
		 try {
			t.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			this.time2 = System.currentTimeMillis();
			/*
			Thread.currentThread().getName()是获得调用这个方法的线程的名字.
			 
		    this.getName()这个方法是获取当前线程对象(ThreadTest1)的名字，只是单纯的方法的调用。
			*/
			System.out.println("runing:"+this.currentThread().getName() +"--耗时:"+(time2-time1) );
	}

	 
	
	 
	
}



