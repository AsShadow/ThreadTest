package org.aaa.web.test.runnableWay;

import java.util.ArrayList;
import java.util.List;

public class Demo {

	public static void main(String[] args) {
		long time1=System.currentTimeMillis();
		
		RunnableTest R=new RunnableTest();
		Thread t1=new Thread(R);
		Thread t2=new Thread(R);
		t1.start();
		t2.start();
		
		List<Thread> list=new ArrayList<Thread>();
		list.add(t1);
		list.add(t2);
		
		try {
			for (Thread item : list) {
				item.join();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long time2=System.currentTimeMillis();
		System.out.println("num:"+R.getNum()+"---耗时:"+(time2-time1));
		
	}

}
