package org.aaa.web.test.callableWay;

import java.util.List;
import java.util.concurrent.Callable;

/**
 * @author shadow
 * 利用Callable接口，创建有返回值的线程。
 */
public class CallableTest implements Callable<Object> {

	public Object call() throws Exception {
		
		
		return null;
	}

	 

	 

}
