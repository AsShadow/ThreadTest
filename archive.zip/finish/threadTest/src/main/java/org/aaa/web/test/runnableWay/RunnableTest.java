package org.aaa.web.test.runnableWay;


/**
 * @author shadow
 * 利用 Runnable 创建线程类似于 继承Thread类  
 */
public class RunnableTest implements Runnable{
    private  int  num;
    private Thread t;
	
    public int getNum() {
    	
    	return num;
    }
    
	 
	public void run() {
		 long time1=System.currentTimeMillis();
		 
		 /*
		   Java中每一个对象都可以作为锁，这是synchronized实现同步的基础：
			1.普通同步方法（实例方法），锁是当前实例对象 ，进入同步代码前要获得当前实例的锁
			2.静态同步方法，锁是当前类的class对象 ，进入同步代码前要获得当前类对象的锁
			3.同步方法块，锁是括号里面的对象，对给定对象加锁，进入同步代码库前要获得给定对象的锁。
		 */
		 //使用synchronized保证线程安全   1.对象锁    2.代码块锁 3.实例方法锁
		 synchronized(this){
				for (int i = 0; i < 10; i++) {
					this.num=num+1;
					//System.out.println("name:"+this.t.currentThread().getName()+"--num"+num);
				}
		 }
		
		 try {
			this.t.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		long time2=System.currentTimeMillis();
		System.out.println("name:"+this.t.currentThread().getName()+"耗时："+(time2-time1));
	}

	
}
