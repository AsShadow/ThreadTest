package org.aaa.web.dao;

import java.util.List;

import org.aaa.web.entity.Test;

public interface CallableMapper {
    
	List<Test> getId();
	
	List<Test> getWord();
}
