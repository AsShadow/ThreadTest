package org.aaa.web.test.callableWay;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

import javax.annotation.Resource;

import org.aaa.web.dao.CallableMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath*:/*.xml")
@Component
public class Demo {
	
	@Autowired
	public CallableMapper callableMapper;
	
	@Test
	public void Test2() {
		System.out.println("多线程");
		long time1=System.currentTimeMillis();
		
		//lambda 表达式---代替匿名内部类
		Callable a=()->{return getId();};
		Callable b=()->{return getWord();};
		 
		
		FutureTask<List> fa=new FutureTask<List>(a);
		FutureTask<List> fb=new FutureTask<List>(b);
		Thread t1 = new Thread(fa);
		t1.start();
		 
		Thread t2 = new Thread(fb);
		t2.start();
		try {
			List list = fa.get();
			List list2 = fb.get();
			
			/*
			 * lambda表达式，可用于
			 * 1.代替匿名内部类
			 * 2.for  in循环遍历数组，map集合等
			 * 3.等等
			*/
			list.forEach(object->System.out.println("id:"+((org.aaa.web.entity.Test) object).getId()));
			list2.forEach(object2-> System.out.println("word:"+((org.aaa.web.entity.Test) object2).getWord()));
//			for (Object object : list) {
//				System.out.println("id:"+((org.aaa.web.entity.Test) object).getId());
//			}
//			for (Object object2 : list2) {
//			    System.out.println("word:"+((org.aaa.web.entity.Test) object2).getWord());
//			}
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		 
		
		long time2=System.currentTimeMillis();
		System.out.println("耗时："+(time2-time1));
		
	}
	
	
	@Test
	public void Test1() {
		
		System.out.println("单线程");
		long time1=System.currentTimeMillis();
		List<org.aaa.web.entity.Test> ids = callableMapper.getId();
		
		for (org.aaa.web.entity.Test test : ids) {
			System.out.println("id:"+test.getId());
		}
		List<org.aaa.web.entity.Test> words = callableMapper.getWord();
		for (org.aaa.web.entity.Test test2 : words) {
			System.out.println("word:"+test2.getWord());
		}
		
		long time2=System.currentTimeMillis();
		System.out.println("耗时："+(time2-time1));
		
	}
	
	
	
	
	public List<org.aaa.web.entity.Test> getId(){
		List<org.aaa.web.entity.Test> ids = callableMapper.getId();
		return ids;
	}
	public List<org.aaa.web.entity.Test> getWord(){
		List<org.aaa.web.entity.Test> words = callableMapper.getWord();
		return words;
	}
	

}
